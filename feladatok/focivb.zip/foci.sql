CREATE DATABASE foci;
USE foci;

CREATE TABLE valogatottak (
    valogatott_id INT PRIMARY KEY,
    orszag VARCHAR(100),
    kontinens VARCHAR(50),
    fifa_kod VARCHAR(10),
    elso_vb_cim_eve INT,
    volt_vilagbajnok BOOLEAN
);

CREATE TABLE stadionok (
    stadion_id INT PRIMARY KEY,
    stadion_nev VARCHAR(100),
    varos VARCHAR(100),
    ferohely INT,
    megnyitas_datuma DATE,
    fedett BOOLEAN
);

CREATE TABLE merkozesek (
    merkozes_id INT PRIMARY KEY,
    szakasz VARCHAR(50),
    hazai_id INT,
    vendeg_id INT,
    datum DATE,
    stadion_id INT,
    hazai_gol INT,
    vendeg_gol INT,
    nezoszam INT,
    hosszabbitas BOOLEAN,
    FOREIGN KEY (hazai_id) REFERENCES valogatottak(valogatott_id),
    FOREIGN KEY (vendeg_id) REFERENCES valogatottak(valogatott_id),
    FOREIGN KEY (stadion_id) REFERENCES stadionok(stadion_id)
);

INSERT INTO valogatottak
(valogatott_id, orszag, kontinens, fifa_kod, elso_vb_cim_eve, volt_vilagbajnok)
VALUES
(1, 'Argentína', 'Dél-Amerika', 'ARG', 1978, TRUE),
(2, 'Franciaország', 'Európa', 'FRA', 1998, TRUE),
(3, 'Brazília', 'Dél-Amerika', 'BRA', 1958, TRUE),
(4, 'Németország', 'Európa', 'GER', 1954, TRUE),
(5, 'Spanyolország', 'Európa', 'ESP', 2010, TRUE),
(6, 'Horvátország', 'Európa', 'CRO', 0, FALSE),
(7, 'Marokkó', 'Afrika', 'MAR', 0, FALSE),
(8, 'Japán', 'Ázsia', 'JPN', 0, FALSE),
(9, 'Anglia', 'Európa', 'ENG', 1966, TRUE),
(10, 'Portugália', 'Európa', 'POR', 0, FALSE),
(11, 'Hollandia', 'Európa', 'NED', 0, FALSE),
(12, 'Uruguay', 'Dél-Amerika', 'URU', 1930, TRUE);

INSERT INTO stadionok
(stadion_id, stadion_nev, varos, ferohely, megnyitas_datuma, fedett)
VALUES
(1, 'Lusail Stadion', 'Lusail', 88966, '2021-11-22', TRUE),
(2, 'Al Bayt Stadion', 'Al Khor', 68895, '2021-11-30', TRUE),
(3, 'Education City Stadion', 'Al Rayyan', 44667, '2020-06-15', TRUE),
(4, 'Ahmad bin Ali Stadion', 'Al Rayyan', 45032, '2020-12-18', TRUE),
(5, 'Al Thumama Stadion', 'Doha', 44400, '2021-10-22', TRUE),
(6, 'Stadium 974', 'Doha', 44089, '2021-11-30', FALSE),
(7, 'Khalifa International Stadion', 'Doha', 45857, '1976-03-01', TRUE),
(8, 'Al Janoub Stadion', 'Al Wakrah', 44325, '2019-05-16', TRUE);

INSERT INTO merkozesek
(merkozes_id, szakasz, hazai_id, vendeg_id, datum, stadion_id, hazai_gol, vendeg_gol, nezoszam, hosszabbitas)
VALUES
(1, 'csoportkör', 1, 2, '2022-11-22', 1, 1, 2, 88200, FALSE),
(2, 'csoportkör', 3, 6, '2022-11-24', 2, 0, 0, 62100, FALSE),
(3, 'csoportkör', 4, 8, '2022-11-27', 3, 1, 2, 43000, FALSE),
(4, 'nyolcaddöntő', 2, 10, '2022-12-04', 5, 3, 1, 42100, FALSE),
(5, 'negyeddöntő', 3, 6, '2022-12-09', 3, 1, 1, 43800, TRUE),
(6, 'negyeddöntő', 1, 11, '2022-12-09', 1, 2, 2, 88000, TRUE),
(7, 'elődöntő', 1, 6, '2022-12-13', 1, 3, 0, 88900, FALSE),
(8, 'elődöntő', 2, 7, '2022-12-14', 2, 2, 0, 68200, FALSE),
(9, 'bronzmérkőzés', 6, 7, '2022-12-17', 7, 2, 1, 44100, FALSE),
(10, 'döntő', 1, 2, '2022-12-18', 1, 3, 3, 88966, TRUE),
(11, 'csoportkör', 5, 4, '2022-11-27', 2, 1, 1, 65000, FALSE),
(12, 'nyolcaddöntő', 9, 7, '2022-12-05', 4, 3, 0, 44000, FALSE),
(13, 'negyeddöntő', 9, 2, '2022-12-10', 2, 1, 2, 68800, FALSE),
(14, 'csoportkör', 12, 10, '2022-11-28', 6, 0, 2, 42000, FALSE);
