SELECT v.kontinens,
       v.orszag,
       COUNT(m.merkozes_id) AS hazai_merkozesek_szama
FROM valogatottak AS v
INNER JOIN merkozesek AS m ON v.valogatott_id = m.hazai_id
GROUP BY v.kontinens, v.valogatott_id, v.orszag
HAVING COUNT(m.merkozes_id) = (
    SELECT MAX(db)
    FROM (

        ...

    ) AS osszesites
    WHERE osszesites.kontinens = v.kontinens
)
ORDER BY v.kontinens, v.orszag;