CREATE DATABASE vegy;
USE vegy;

CREATE TABLE raktarak (
    raktar_id INT PRIMARY KEY,
    raktar_nev VARCHAR(100),
    helyiseg VARCHAR(50),
    kapacitas_liter DECIMAL(5,1),
    szelloztetett BOOLEAN
);

CREATE TABLE vegyuletek (
    vegyulet_id INT PRIMARY KEY,
    nev VARCHAR(100),
    keplet VARCHAR(30),
    tipus VARCHAR(50),
    molaris_tomeg DECIMAL(6,2),
    veszelyes BOOLEAN,
    beszerzes_datuma DATE,
    raktar_id INT,
    FOREIGN KEY (raktar_id) REFERENCES raktarak(raktar_id)
);

CREATE TABLE kiserletek (
    kiserlet_id INT PRIMARY KEY,
    kiserlet_nev VARCHAR(100),
    vegyulet_id INT,
    datum DATE,
    evfolyam INT,
    tanari_felugyelet BOOLEAN,
    idotartam_perc INT,
    FOREIGN KEY (vegyulet_id) REFERENCES vegyuletek(vegyulet_id)
);

INSERT INTO raktarak
(raktar_id, raktar_nev, helyiseg, kapacitas_liter, szelloztetett)
VALUES
(1, 'Általános vegyszerszekrény', 'Kémia labor', 18.5, TRUE),
(2, 'Savszekrény', 'Előkészítő', 12.0, TRUE),
(3, 'Lúgszekrény', 'Előkészítő', 10.0, TRUE),
(4, 'Gyúlékony anyagok szekrénye', 'Kémia labor', 8.0, TRUE),
(5, 'Hűtött tároló', 'Kémia labor', 5.0, FALSE);

INSERT INTO vegyuletek
(vegyulet_id, nev, keplet, tipus, molaris_tomeg, veszelyes, beszerzes_datuma, raktar_id)
VALUES
(1, 'Nátrium-klorid', 'NaCl', 'só', 58.44, FALSE, '2021-03-12', 1),
(2, 'Sósav', 'HCl', 'sav', 36.46, TRUE, '2020-11-05', 2),
(3, 'Nátrium-hidroxid', 'NaOH', 'bázis', 40.00, TRUE, '2022-01-18', 3),
(4, 'Etanol', 'C2H6O', 'alkohol', 46.07, TRUE, '2023-09-02', 4),
(5, 'Réz-szulfát', 'CuSO4', 'só', 159.61, FALSE, '2021-06-20', 1),
(6, 'Kénsav', 'H2SO4', 'sav', 98.08, TRUE, '2019-10-14', 2),
(7, 'Kalcium-karbonát', 'CaCO3', 'só', 100.09, FALSE, '2024-02-08', 1),
(8, 'Ammóniaoldat', 'NH3', 'bázis', 17.03, TRUE, '2023-04-27', 3),
(9, 'Glükóz', 'C6H12O6', 'szénhidrát', 180.16, FALSE, '2022-12-01', 5),
(10, 'Aceton', 'C3H6O', 'keton', 58.08, TRUE, '2024-05-16', 4),
(11, 'Vas(III)-klorid', 'FeCl3', 'só', 162.20, TRUE, '2020-07-09', 1),
(12, 'Ecetsav', 'CH3COOH', 'sav', 60.05, FALSE, '2023-01-22', 2);

INSERT INTO kiserletek
(kiserlet_id, kiserlet_nev, vegyulet_id, datum, evfolyam, tanari_felugyelet, idotartam_perc)
VALUES
(1, 'Lángfestés vizsgálata', 1, '2024-09-16', 10, FALSE, 45),
(2, 'Semlegesítési reakció', 2, '2024-09-23', 11, TRUE, 45),
(3, 'Réz-szulfát kristályosítása', 5, '2024-10-07', 9, FALSE, 60),
(4, 'Szappankészítés modellkísérlet', 3, '2024-10-21', 12, TRUE, 60),
(5, 'Alkohol égése', 4, '2024-11-04', 10, TRUE, 30),
(6, 'Sav-bázis indikátorok', 6, '2024-11-18', 11, TRUE, 45),
(7, 'Mészkő reakciója savval', 7, '2024-12-02', 9, FALSE, 45),
(8, 'Ammónia kimutatása', 8, '2025-01-13', 12, TRUE, 45),
(9, 'Szőlőcukor kimutatása', 9, '2025-01-27', 10, FALSE, 45),
(10, 'Oldószerek párolgása', 10, '2025-02-10', 11, TRUE, 30),
(11, 'Vas(III)-ion kimutatása', 11, '2025-02-24', 12, TRUE, 45),
(12, 'Ecetsav töménységének becslése', 12, '2025-03-10', 11, FALSE, 45);
