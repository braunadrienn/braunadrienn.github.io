CREATE DATABASE erdo;
USE erdo;

CREATE TABLE fafajok (
    fafaj_id INT PRIMARY KEY,
    magyar_nev VARCHAR(100),
    latin_nev VARCHAR(100),
    csoport VARCHAR(50),
    atlagos_elettartam_ev INT,
    oshonos BOOLEAN
);

CREATE TABLE erdoreszletek (
    erdor_id INT PRIMARY KEY,
    erdor_nev VARCHAR(100),
    terep_tipus VARCHAR(50),
    terulet_hektar DECIMAL(5,1),
    felmeres_datuma DATE,
    vedett BOOLEAN,
    fafaj_id INT,
    FOREIGN KEY (fafaj_id) REFERENCES fafajok(fafaj_id)
);

CREATE TABLE munkalatok (
    munkalat_id INT PRIMARY KEY,
    munkalat_tipus VARCHAR(100),
    erdor_id INT,
    kezdes_datuma DATE,
    idotartam_nap INT,
    koltseg_ft INT,
    engedelykoteles BOOLEAN,
    FOREIGN KEY (erdor_id) REFERENCES erdoreszletek(erdor_id)
);

INSERT INTO fafajok
(fafaj_id, magyar_nev, latin_nev, csoport, atlagos_elettartam_ev, oshonos)
VALUES
(1, 'Közönséges bükk', 'Fagus sylvatica', 'lombhullató', 120, TRUE),
(2, 'Fehér nyár', 'Populus alba', 'lombhullató', 70, FALSE),
(3, 'Kocsányos tölgy', 'Quercus robur', 'lombhullató', 200, TRUE),
(4, 'Erdeifenyő', 'Pinus sylvestris', 'tűlevelű', 150, FALSE),
(5, 'Fehér akác', 'Robinia pseudoacacia', 'lombhullató', 90, FALSE),
(6, 'Gyertyán', 'Carpinus betulus', 'lombhullató', 100, TRUE),
(7, 'Magyar kőris', 'Fraxinus angustifolia', 'lombhullató', 130, TRUE),
(8, 'Csertölgy', 'Quercus cerris', 'lombhullató', 160, FALSE),
(9, 'Mézgás éger', 'Alnus glutinosa', 'lombhullató', 110, TRUE),
(10, 'Mezei juhar', 'Acer campestre', 'lombhullató', 120, FALSE);

INSERT INTO erdoreszletek
(erdor_id, erdor_nev, terep_tipus, terulet_hektar, felmeres_datuma, vedett, fafaj_id)
VALUES
(1, 'Bükkös-völgy', 'hegyvidéki', 34.6, '2019-03-18', TRUE, 1),
(2, 'Nyáras-lapos', 'ártéri', 22.4, '2020-05-11', FALSE, 2),
(3, 'Tölgyes-hát', 'dombvidéki', 41.8, '2018-09-24', TRUE, 3),
(4, 'Fenyves-oldal', 'hegyvidéki', 29.5, '2021-04-07', TRUE, 4),
(5, 'Akácos-dűlő', 'síkvidéki', 18.7, '2022-10-13', FALSE, 5),
(6, 'Gyertyános-rét', 'dombvidéki', 25.9, '2020-02-28', TRUE, 6),
(7, 'Kőris-liget', 'ártéri', 16.3, '2023-06-19', FALSE, 7),
(8, 'Cseres-tető', 'dombvidéki', 37.2, '2017-11-03', TRUE, 8),
(9, 'Égeres-mélyedés', 'lápos', 12.8, '2024-01-15', FALSE, 9),
(10, 'Vegyeserdő-nyiladék', 'síkvidéki', 31.4, '2021-08-30', TRUE, 10),
(11, 'Fenyőtelep', 'hegyvidéki', 20.6, '2019-12-02', FALSE, 4),
(12, 'Tölgyes-berek', 'ártéri', 27.1, '2022-03-09', TRUE, 3);

INSERT INTO munkalatok
(munkalat_id, munkalat_tipus, erdor_id, kezdes_datuma, idotartam_nap, koltseg_ft, engedelykoteles)
VALUES
(1, 'tisztítás', 1, '2024-03-12', 6, 420000, FALSE),
(2, 'csemeteültetés', 2, '2024-04-08', 12, 960000, TRUE),
(3, 'gyérítés', 3, '2024-05-20', 9, 780000, FALSE),
(4, 'vadkár elleni védekezés', 4, '2024-06-03', 4, 310000, TRUE),
(5, 'sarjaztatás felmérése', 5, '2024-06-24', 3, 180000, FALSE),
(6, 'egészségügyi termelés', 6, '2024-07-15', 8, 690000, TRUE),
(7, 'invazív fajok eltávolítása', 7, '2024-08-05', 7, 540000, TRUE),
(8, 'felújító vágás', 8, '2024-09-02', 14, 1250000, TRUE),
(9, 'vízrendezési beavatkozás', 9, '2024-09-23', 10, 870000, TRUE),
(10, 'erdősítés pótlása', 10, '2024-10-14', 11, 930000, FALSE),
(11, 'tűzpászta karbantartás', 11, '2024-11-04', 5, 350000, FALSE),
(12, 'élőhelyvédelmi munka', 12, '2024-11-25', 6, 610000, TRUE),
(13, 'állományfelmérés', 1, '2025-02-10', 4, 220000, FALSE),
(14, 'újulatvédelem', 3, '2025-03-03', 5, 390000, TRUE);
